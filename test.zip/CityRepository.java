public interface CityRepository extends JpaRepository<City, Long> {
}
