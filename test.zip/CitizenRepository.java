public interface CitizenRepository extends JpaRepository<Citizen, Long> {
}
