import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/citizens")
@CrossOrigin
public class CitizenController {

    private final CitizenService citizenService;

    @Autowired
    public CitizenController(CitizenService citizenService) {
        this.citizenService = citizenService;
    }

    @PostMapping
    public ResponseEntity<Citizen> create(@RequestBody Citizen citizen) {
        Citizen savedCitizen = citizenService.save(citizen);
        return ResponseEntity.ok()
            .body(savedCitizen);
    }

    @GetMapping
    public ResponseEntity<List<Citizen>> fetchAll() {
        List<Citizen> found = citizenService.findAll();
        return ResponseEntity.ok()
            .body(found);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Citizen> fetchById(@PathVariable Long id) {
        Citizen found = citizenService.findById(id);
        return ResponseEntity.ok()
            .body(found);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Citizen> updateById(@RequestBody Citizen citizen, @PathVariable Long id) {
        Citizen toUpdate = citizenService.findById(id);
        toUpdate.setName(citizen.getName());
        toUpdate.setAge(citizen.getAge());

        Citizen updated = citizenService.update(toUpdate);
        return ResponseEntity.ok()
            .body(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteById(@PathVariable Long id) {
        citizenService.deleteById(id);
        return ResponseEntity.ok()
            .build();
    }

}
