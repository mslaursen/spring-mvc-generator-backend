package com.x.y.z;

import com.x.y.z;
import com.x.y.z.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/city2s")
@CrossOrigin
public class City2Controller {

    private final City2Service city2Service;

    @Autowired
    public City2Controller(City2Service city2Service) {
        this.city2Service = city2Service;
    }

    @PostMapping
    public ResponseEntity<City2> create(@RequestBody City2 city2) {
        City2 savedCity2 = city2Service.save(city2);
        return ResponseEntity.ok()
            .body(savedCity2);
    }

    @GetMapping
    public ResponseEntity<List<City2>> fetchAll() {
        List<City2> found = city2Service.findAll();
        return ResponseEntity.ok()
            .body(found);
    }

    @GetMapping("/{id}")
    public ResponseEntity<City2> fetchById(@PathVariable Long id) {
        City2 found = city2Service.findById(id);
        return ResponseEntity.ok()
            .body(found);
    }

}
