import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AService {

    private final ARepository aRepository;

    @Autowired
    public AService(ARepository aRepository) {
        this.aRepository = aRepository;
    }

    public A save(A a) {
        return aRepository.save(a);
    }

    public List<A> findAll() {
        return aRepository.findAll();
    }

    public A findById(Long id) {
        return aRepository.findById(id).orElseThrow();
    }

    public A update(A toUpdate) {
        return aRepository.save(toUpdate);
    }

    public void deleteById(Long id) {
        aRepository.deleteById(id);
    }

}
