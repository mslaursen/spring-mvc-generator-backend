import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CitizenService {

    private final CitizenRepository citizenRepository;

    @Autowired
    public CitizenService(CitizenRepository citizenRepository) {
        this.citizenRepository = citizenRepository;
    }

    public Citizen save(Citizen citizen) {
        return citizenRepository.save(citizen);
    }

    public List<Citizen> findAll() {
        return citizenRepository.findAll();
    }

    public Citizen findById(Long id) {
        return citizenRepository.findById(id).orElseThrow();
    }

    public Citizen update(Citizen toUpdate) {
        return citizenRepository.save(toUpdate);
    }

    public void deleteById(Long id) {
        citizenRepository.deleteById(id);
    }

}
