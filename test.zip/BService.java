import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BService {

    private final BRepository bRepository;

    @Autowired
    public BService(BRepository bRepository) {
        this.bRepository = bRepository;
    }

    public B save(B b) {
        return bRepository.save(b);
    }

    public List<B> findAll() {
        return bRepository.findAll();
    }

    public B findById(Long id) {
        return bRepository.findById(id).orElseThrow();
    }

    public B update(B toUpdate) {
        return bRepository.save(toUpdate);
    }

    public void deleteById(Long id) {
        bRepository.deleteById(id);
    }

}
