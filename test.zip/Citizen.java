@Getter
@Setter
@ToString
@Entity
public class Citizen {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JsonBackReference
    private City city;

    private String name;
    private Integer age;
}
