import org.springframework.data.jpa.repository.JpaRepository;

public interface BRepository extends JpaRepository<B, Long> {
}
