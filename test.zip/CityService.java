@Service
public class CityService {

    private final CityRepository cityRepository;

    @Autowired
    public CityService(CityRepository cityRepository) {
        this.cityRepository = cityRepository;
    }

    public City save(City city) {
        return cityRepository.save(city);
    }

    public List<City> findAll() {
        return cityRepository.findAll();
    }

    public City findById(Long id) {
        return cityRepository.findById(id).orElseThrow();
    }

    public City update(City toUpdate) {
        return cityRepository.save(toUpdate);
    }

    public void deleteById(Long id) {
        cityRepository.deleteById(id);
    }

}
