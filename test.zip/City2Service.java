@Service
public class City2Service {

    private final City2Repository city2Repository;

    @Autowired
    public City2Service(City2Repository city2Repository) {
        this.city2Repository = city2Repository;
    }

    public City2 save(City2 city2) {
        return city2Repository.save(city2);
    }

    public List<City2> findAll() {
        return city2Repository.findAll();
    }

    public City2 findById(Long id) {
        return city2Repository.findById(id).orElseThrow();
    }

}
