import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/as")
@CrossOrigin
public class AController {

    private final AService aService;

    @Autowired
    public AController(AService aService) {
        this.aService = aService;
    }

    @PostMapping
    public ResponseEntity<A> create(@RequestBody A a) {
        A savedA = aService.save(a);
        return ResponseEntity.ok()
            .body(savedA);
    }

    @GetMapping
    public ResponseEntity<List<A>> fetchAll() {
        List<A> found = aService.findAll();
        return ResponseEntity.ok()
            .body(found);
    }

    @GetMapping("/{id}")
    public ResponseEntity<A> fetchById(@PathVariable Long id) {
        A found = aService.findById(id);
        return ResponseEntity.ok()
            .body(found);
    }

    @PutMapping("/{id}")
    public ResponseEntity<A> updateById(@RequestBody A a, @PathVariable Long id) {
        A toUpdate = aService.findById(id);

        A updated = aService.update(toUpdate);
        return ResponseEntity.ok()
            .body(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteById(@PathVariable Long id) {
        aService.deleteById(id);
        return ResponseEntity.ok()
            .build();
    }

}
