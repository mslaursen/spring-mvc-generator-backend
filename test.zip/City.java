package null.spring mvc generator.entity

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@ToString
@Entity
public class City {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany(mappedBy = "city", cascade = CascadeType.ALL)
    @ToString.Exclude
    @JsonManagedReference
    private List<City> cityList

    @ManyToOne
    @JsonBackReference
    private Man man;

    @Column(name = "age_limit")
    private Integer AgeLimit;
}
