@Getter
@Setter
@ToString
@Entity
public class City {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany(mappedBy = "city", cascade = CascadeType.ALL)
    @ToString.Exclude
    @JsonManagedReference
    private List<Citizen> citizenList

    private String name;
    private Integer population;
}
