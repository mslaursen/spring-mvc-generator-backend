import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bs")
@CrossOrigin
public class BController {

    private final BService bService;

    @Autowired
    public BController(BService bService) {
        this.bService = bService;
    }

    @PostMapping
    public ResponseEntity<B> create(@RequestBody B b) {
        B savedB = bService.save(b);
        return ResponseEntity.ok()
            .body(savedB);
    }

    @GetMapping
    public ResponseEntity<List<B>> fetchAll() {
        List<B> found = bService.findAll();
        return ResponseEntity.ok()
            .body(found);
    }

    @GetMapping("/{id}")
    public ResponseEntity<B> fetchById(@PathVariable Long id) {
        B found = bService.findById(id);
        return ResponseEntity.ok()
            .body(found);
    }

    @PutMapping("/{id}")
    public ResponseEntity<B> updateById(@RequestBody B b, @PathVariable Long id) {
        B toUpdate = bService.findById(id);

        B updated = bService.update(toUpdate);
        return ResponseEntity.ok()
            .body(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteById(@PathVariable Long id) {
        bService.deleteById(id);
        return ResponseEntity.ok()
            .build();
    }

}
