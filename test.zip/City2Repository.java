public interface City2Repository extends JpaRepository<City2, Long> {
}
